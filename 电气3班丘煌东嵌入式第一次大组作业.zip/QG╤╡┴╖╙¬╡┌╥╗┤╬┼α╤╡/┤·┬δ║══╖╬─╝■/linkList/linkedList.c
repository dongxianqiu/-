#include "linkedList.h"
#include "stdlib.h"
#include "stdio.h"
#include "string.h"
 extern int n=0,m=0;
  void print(LNode *head)              //��ӡ�������
{
	LNode *p;
	p=head;
	while(NULL!=p)
	{
		printf("%d->",p->data);       
		p=p->next;
	}
	printf("\n");
}
/**
 *  @name        : Status InitList(LinkList *L);
 *	@description : initialize an empty linked list with only the head node without value
 *	@param		 : L(the head node)
 *	@return		 : Status
 *  @notice      : None
 */
Status InitList(LinkedList *L) 
{
		
	if	(*L!=NULL)	 
	{  
	   *L=NULL;   
	    
       if(*L!=NULL ) return ERROR;
       else    n=0,m=0;  return SUCCESS;    
	}	
	
	else       return SUCCESS;
}
	

/**
 *  @name        : void DestroyList(LinkedList *L)
 *	@description : destroy a linked list, free all the nodes
 *	@param		 : L(the head node)
 *	@return		 : None
 *  @notice      : None
 */

void DestroyList(LinkedList *L) 
{
	LNode *p;
	p=(*L);
    if(p == NULL)                  //���ж��Ƿ�Ϊ��
    {
        printf("������Ϊ��,�޷����\n");

    } 
    else
    {
    while( p->next != NULL )        
    {
       p = (*L)->next;        //����ɾ��
        free(*L);n-=1;m-=1;
        *L = p;
    }
      free(*L);n-=1;m-=1;                  // ������һ�����   
      printf("�����Ѿ����\n");
    }
    
}    

/**
 *  @name        : Status InsertList(LNode *p, LNode *q)
 *	@description : insert node q after node p
 *	@param		 : p, q
 *	@return		 : Status
 *  @notice      : None
 */
	
Status InsertList(LNode *p, LNode *q) {
	
}
	
/**
 *  @name        : Status DeleteList(LNode *p, ElemType *e)
 *	@description : delete the first node after the node p and assign its value to e
 *	@param		 : p, e
 *	@return		 : Status
 *  @notice      : None
 */

Status DeleteList(LNode *p, ElemType *e)
{ 
    LNode  *p11,*p2;
	
	if( NULL == p)            
    {
        printf( "Ϊ������,�޷�ɾ��\n");    //���������
        return ERROR;
    }  
    	p11 = p2 = p;
      if(p != NULL);   	  	
      {
    		while( (p11->data!=(*e)) && (p11->next!=NULL ))   //ƥ���������ڵ������ڵ�
    	{
    		p2 = p11;                                        //ɾ����ʱΪ����,֮��Ľ�
    		p11 = p11->next;
    	  }
    	   if( p11->data==(*e) )
    	   {
    		   p2->next = p11->next; 
    		   free(p11); n-=1;m-=1;	
    		
    		printf("�Ѿ�ɾ������%d\n",*e);
           
    	   }return SUCCESS;
    	}

    	printf("û���ҵ�������,����������\n");     
    
    return SUCCESS;
}

/**
 *  @name        : void TraverseList(LinkedList L, void (*visit)(ElemType e))
 *	@description : traverse the linked list and call the funtion visit
 *	@param		 : L(the head node), visit 
 *	@return		 : None
 *  @notice      : None
 */

void TraverseList(LinkedList L, void (*visit)(ElemType e))  
{
	int end;
	LNode *p;
	p = L;
		
   while(NULL!=p->next) 
    {  
    	p = p->next;
        end = p->data;
    }
       (*visit)(end);   
	
}


/**
 *  @name        : Status SearchList(LinkedList L, ElemType e)
 *	@description : find the first node in the linked list according to e 
 *	@param		 : L(the head node), e
 *	@return		 : Status
 *  @notice      : None
 */


Status SearchList(LinkedList L, ElemType e) 
{
	LNode *p;
	int i=1;
	p = L;
	if(L==NULL) 
	{
		printf("�������ǲ��ܲ��ҵģ�\n");return ERROR;
	}
	if(  e == p->data )    
	{
		printf("%d�����ڵ�һ��λ��\n",e);  return SUCCESS;  //���Ե�һλ����
	}
	
	if( p->data != e )
     {
        
         while((NULL!=p->next)&&( p->data!=e))        // �������ݲ���
       	{
       		 p=p->next;i++;       	  
       	} 	                                          	    	  		  
	     if((i <=n )&&(e == p->data) )             //�Խ���ѭ�������ݺ�i�ж�
	    {
	  	 printf("%d�����ڵ�%dλ��\n",e,i);       return SUCCESS;       //�����ڵڼ����� 
	  	 
	    }
	    else  return ERROR; 
     } 
     else  return ERROR;
  
}


/**
 *  @name        : Status ReverseList(LinkedList *L)
 *	@description : reverse the linked list 
 *	@param		 : L(the head node)
 *	@return		 : Status
 *  @notice      : None
 */

LNode* ReverseEvenList(LinkedList *L) 
{
	LNode *p,*p1,*r;
	 p=p1=r=(*L);  
	 
    if( ( NULL==(*L) ) ||  ( NULL==(*L)->next )   )  
     {
     	printf("���������Ͳ��û��˰�\n");
     	return *L;      
     }
     else
     {
          
      p1 = (*L)->next;  
      (*L)->next = NULL;     
    
      while(p1!=NULL)
      {  
        r = p1->next;               //����������������; 
        p1->next = p;  
        p = p1;   
        p1 = r;       
      }
      print(p);
      return p;               // q��r��ָ��NULL,��ʱ����pΪͷָ��
    }
    return p;
}


/**
 *  @name        : Status IsLoopList(LinkedList L)
 *	@description : judge whether the linked list is looped
 *	@param		 : L(the head node)
 *	@return		 : Status
 *  @notice      : None
 */


Status IsLoopList(LinkedList L) 
{
	LNode *fast,*slow;
	fast=slow=L;

	while(fast!=NULL&&fast->next!=NULL)    //���ɻ�fast��Ȼ��NULL
	{				
		fast=fast->next;				
		fast=fast->next;		            // ��ָ��������
		slow=slow->next;
		
		
	}
	if(fast==slow) 	return SUCCESS;
	else         	return ERROR;
	
}

/**
 *  @name        : LNode* ReverseEvenList(LinkedList *L)
 *	@description : reverse the nodes which value is an even number in the linked list, input: 1 -> 2 -> 3 -> 4  output: 2 -> 1 -> 4 -> 3
 *	@param		 : L(the head node)
 *	@return		 : LNode(the new head node)
 *  @notice      : choose to finish 
 */


/**
 *  @name        : LNode* FindMidNode(LinkedList *L)
 *	@description : find the middle node in the linked list
 *	@param		 : L(the head node)
 *	@return		 : LNode
 *  @notice      : choose to finish 
 */
	
LNode* FindMidNode(LinkedList *L) 
{
	LNode *p2,*p1;
	int i=1;
	p1=p2=(*L);
	if(NULL==p1)
	{ 
		printf("������Ϊ��\n");return p1;
		}
	if(p1->next==NULL)
	 {
	 	printf("����ֻ��һ��\n");return p1;	
	 }
	else
	{

	     while( p1->next->next!=NULL )           //һ���߿�,��һ������
    	  {
    		p2 = p2->next;
    		p1 = p1->next->next;
    		i++; 		                           //ͳ�����˼���
    	   }
    	 printf("�м�ڵ�Ϊ��%d����%d\n",i,p2->data);      
    	 return p2;
	}return p1;
   
}

